//
//  FirebaseManager.swift
//  FirebaseTraining
//
//  Created by kimseongjun on 2023/05/30.
//

import Foundation
import FirebaseDatabase

class FirebaseManager {
    let db = Database.database().reference()
    let schedule1 = Schedule(title: "Hi", content: "Bye", expirationDate: Date())
    let schedule2 = Schedule(title: "Hi", content: "Bye", expirationDate: Date())
    
    
    func insertData() {
        db.child("schedule").setValue(["schedule1": "asd", "schedule2": "zxc"])
    }
    
    func fetchData() {
        db.child("schedule").observeSingleEvent(of: .value) { snapshot in
            print(snapshot)
            let value = snapshot.value
            print(value)
        }
    }
}

struct Schedule: Hashable {
    let id = UUID()
    let title: String
    let content: String
    let expirationDate: Date
    
    init(title: String = "", content: String = "", expirationDate: Date = Date()) {
        self.title = title
        self.content = content
        self.expirationDate = expirationDate
    }
}
