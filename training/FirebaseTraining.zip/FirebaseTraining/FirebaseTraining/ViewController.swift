//
//  ViewController.swift
//  FirebaseTraining
//
//  Created by kimseongjun on 2023/05/30.
//

import UIKit

class ViewController: UIViewController {

    let firebase = FirebaseManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        firebase.insertData()
        firebase.fetchData()
    }


}

